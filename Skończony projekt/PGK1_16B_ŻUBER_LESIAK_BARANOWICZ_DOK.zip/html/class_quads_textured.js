var class_quads_textured =
[
    [ "QuadsTextured", "class_quads_textured.html#aff573658b41c441dfaad8692ba7dcac0", null ]
];