var class_textured =
[
    [ "getTextured", "class_textured.html#a6a4bd5e6892d4cbbd4182ccaabc25796", null ],
    [ "setTextureId", "class_textured.html#ab6a5996c5d5dc033bc95892e48c58a83", null ],
    [ "textureId", "class_textured.html#aef9b4b3e991b67661e98bc5f77a3f0b9", null ]
];