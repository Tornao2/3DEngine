var class_quads =
[
    [ "Quads", "class_quads.html#a5ffd55b631bffd4b8e2a605bdcea3645", null ],
    [ "drawDirect", "class_quads.html#a3dcac04451ac4317dda293064de3a637", null ]
];