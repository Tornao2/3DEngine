var class_shader =
[
    [ "Shader", "class_shader.html#a0d654ebaca4e0555197c0724c6d30610", null ],
    [ "getProgramId", "class_shader.html#a91ea0fb26cc6f269b7ece13c8cb39dd3", null ],
    [ "getVAO", "class_shader.html#ae358261627b77c38aa179f39d311af2a", null ],
    [ "getVBO", "class_shader.html#a98e6eb583587b7c1db60ccbcc99f98d4", null ],
    [ "switchShading", "class_shader.html#a9bf33545b25f4fd9b0d17f667c96e609", null ],
    [ "use", "class_shader.html#a870fa9f13d69e558815d6fd351a469dc", null ]
];