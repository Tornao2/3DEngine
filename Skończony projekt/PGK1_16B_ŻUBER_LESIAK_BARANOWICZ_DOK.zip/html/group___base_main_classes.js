var group___base_main_classes =
[
    [ "EngineObject.h", "_engine_object_8h.html", null ],
    [ "DirectDraw", "class_direct_draw.html", [
      [ "drawDirect", "class_direct_draw.html#a4e88e6b5973cd0f908f302decf02bb16", null ]
    ] ]
];