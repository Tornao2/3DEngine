var class_poli_line =
[
    [ "PoliLine", "class_poli_line.html#ade507ae9db716e6732cb76578ed5768a", null ],
    [ "addPoint", "class_poli_line.html#a22997cca3d5bd32e60bafd431721a889", null ],
    [ "drawDirect", "class_poli_line.html#a4eb5d7bffa182a9091dc5d89eb1aafc4", null ],
    [ "getIfClosed", "class_poli_line.html#a1e7e25fa56070f44fd201565e5c04e3b", null ],
    [ "removePoint", "class_poli_line.html#a16a1bda506ff58cc5fb5fef8c28bade8", null ],
    [ "setIfClosed", "class_poli_line.html#a34369df1827e2a79b538321483313a29", null ]
];