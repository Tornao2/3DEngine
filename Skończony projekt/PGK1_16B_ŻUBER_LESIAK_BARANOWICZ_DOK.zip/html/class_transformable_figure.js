var class_transformable_figure =
[
    [ "freeTransform", "class_transformable_figure.html#a441ea588691226f35a299cb1ac8ec631", null ],
    [ "rotate", "class_transformable_figure.html#ab8b04c2693506f8f1834331997d05e6a", null ],
    [ "scale", "class_transformable_figure.html#a677c3be513b17b1a0f80260d521fc69d", null ],
    [ "translate", "class_transformable_figure.html#a1aab0908d660a36cd2d73cf07f528160", null ]
];