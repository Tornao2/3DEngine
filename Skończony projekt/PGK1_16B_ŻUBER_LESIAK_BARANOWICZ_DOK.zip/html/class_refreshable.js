var class_refreshable =
[
    [ "getIfRefresh", "class_refreshable.html#a272fe086c786048f387dbd9e72b0fe68", null ],
    [ "setIfRefresh", "class_refreshable.html#aadb1a473dae89bf9f38dc8560bfcc241", null ],
    [ "callForRefresh", "class_refreshable.html#a2b1990a59ab10f3d37e922544febeb2b", null ]
];