var class_triangle_strip =
[
    [ "TriangleStrip", "class_triangle_strip.html#aba28e4539295df3e9e2006e1530641e8", null ],
    [ "addPoint", "class_triangle_strip.html#a2a9e36dad1e4045a2dfb1976b886b785", null ],
    [ "drawDirect", "class_triangle_strip.html#a9f4e94d85e134c9ce99eb8b3a2b81613", null ],
    [ "removePoint", "class_triangle_strip.html#ad57351e2bac47c5ece0ea985502bd98e", null ]
];