var searchData=
[
  ['data_0',['data',['../class_figures.html#ab377ebe70185be8f7df3e2197508272d',1,'Figures']]]
];
