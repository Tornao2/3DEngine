var searchData=
[
  ['pitch_0',['pitch',['../class_observer.html#a1d7c01e4d570ba47d84f606d7c718322',1,'Observer']]]
];
