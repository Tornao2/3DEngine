var searchData=
[
  ['figuree_0',['FigureE',['../class_figure_e.html#ac48367dfca4ef46979e604877c2ce932',1,'FigureE']]],
  ['freetransform_1',['freeTransform',['../class_transformable_figure.html#a441ea588691226f35a299cb1ac8ec631',1,'TransformableFigure']]]
];
