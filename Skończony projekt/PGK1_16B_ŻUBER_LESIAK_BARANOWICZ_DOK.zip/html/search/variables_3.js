var searchData=
[
  ['id_0',['id',['../class_engine_object.html#a756147c1cf310c0fbc623189345bc814',1,'EngineObject']]],
  ['indices_1',['indices',['../class_indice_draw.html#a990941076d29a3eade1f2aba7fca0b47',1,'IndiceDraw']]],
  ['instance_2',['instance',['../class_player.html#a17c8dcb98b576527a2d20b992c3c3009',1,'Player']]],
  ['istextured_3',['isTextured',['../class_figures.html#a136194427a698f8ae10a80becfdab035',1,'Figures']]]
];
