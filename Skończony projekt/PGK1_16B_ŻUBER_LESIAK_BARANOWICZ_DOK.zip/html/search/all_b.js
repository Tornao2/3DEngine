var searchData=
[
  ['objectmanager_0',['ObjectManager',['../class_object_manager.html',1,'ObjectManager'],['../class_object_manager.html#a6fa9372c7c3a8da88412f4158ca3dfd9',1,'ObjectManager::ObjectManager()']]],
  ['observer_1',['Observer',['../class_observer.html',1,'Observer'],['../class_observer.html#a96861bf5071b9e4d1d08000542fd4500',1,'Observer::Observer()']]]
];
