var searchData=
[
  ['quads_0',['Quads',['../class_quads.html#a5ffd55b631bffd4b8e2a605bdcea3645',1,'Quads']]],
  ['quadstextured_1',['QuadsTextured',['../class_quads_textured.html#aff573658b41c441dfaad8692ba7dcac0',1,'QuadsTextured']]]
];
