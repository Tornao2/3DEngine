var searchData=
[
  ['shader_0',['shader',['../class_observer.html#a8916d69fe819dd7781805cfba42e144f',1,'Observer']]],
  ['sidelength_1',['sideLength',['../class_cube.html#a9b32f2614314ac19b6a048d44669ce51',1,'Cube']]],
  ['size_2',['size',['../class_resizable.html#ad6552a8e871edc7b14c7d82214dbf81e',1,'Resizable']]]
];
