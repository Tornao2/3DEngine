var searchData=
[
  ['główne_20bazowe_20klasy_0',['Główne bazowe klasy',['../group___base_main_classes.html',1,'']]]
];
