var searchData=
[
  ['up_0',['up',['../class_observer.html#a7eb9c590209352712b73bb9c1ee14eb4',1,'Observer']]]
];
