var searchData=
[
  ['objectmanager_0',['ObjectManager',['../class_object_manager.html',1,'']]],
  ['observer_1',['Observer',['../class_observer.html',1,'']]]
];
