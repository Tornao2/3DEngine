var indexSectionsWithContent =
{
  0: "abcdefgiklmopqrstuvxyz",
  1: "bcdefiklmopqrst",
  2: "abcdefgiklmopqrstu",
  3: "acdilmpstuvxyz"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "Wszystko",
  1: "Klasy",
  2: "Funkcje",
  3: "Zmienne"
};

