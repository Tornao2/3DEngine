var searchData=
[
  ['updatecamera_0',['updateCamera',['../class_observer.html#ae29817a2746a51e82b0ae377d8192386',1,'Observer']]],
  ['updateindex_1',['updateIndex',['../class_figures.html#a015e3ec22f9dc2d69cfebf39d5b1961a',1,'Figures']]],
  ['use_2',['use',['../class_shader.html#a870fa9f13d69e558815d6fd351a469dc',1,'Shader']]]
];
