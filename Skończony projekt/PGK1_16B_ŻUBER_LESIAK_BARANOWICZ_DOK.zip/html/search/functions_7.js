var searchData=
[
  ['iffullscreen_0',['ifFullscreen',['../class_display_manager.html#aece7ddf38c3180c77c69003e7bfbf8db',1,'DisplayManager']]],
  ['initializewindow_1',['initializeWindow',['../class_display_manager.html#a9e8faef58efc226ca622d08f3930c9a4',1,'DisplayManager']]],
  ['isactive_2',['isActive',['../class_engine_object.html#a0f96ee69f4ea27845250c9f7a2063cb5',1,'EngineObject']]]
];
