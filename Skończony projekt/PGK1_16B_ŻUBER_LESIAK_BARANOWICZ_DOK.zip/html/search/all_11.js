var searchData=
[
  ['up_0',['up',['../class_observer.html#a7eb9c590209352712b73bb9c1ee14eb4',1,'Observer']]],
  ['updatecamera_1',['updateCamera',['../class_observer.html#ae29817a2746a51e82b0ae377d8192386',1,'Observer']]],
  ['updateindex_2',['updateIndex',['../class_figures.html#a015e3ec22f9dc2d69cfebf39d5b1961a',1,'Figures']]],
  ['use_3',['use',['../class_shader.html#a870fa9f13d69e558815d6fd351a469dc',1,'Shader']]]
];
