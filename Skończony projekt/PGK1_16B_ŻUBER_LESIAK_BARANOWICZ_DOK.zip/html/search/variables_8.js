var searchData=
[
  ['target_0',['target',['../class_observer.html#a79e6395080bea390b2ae56c1167fbcaf',1,'Observer']]],
  ['textureid_1',['textureId',['../class_textured.html#aef9b4b3e991b67661e98bc5f77a3f0b9',1,'Textured']]]
];
