var searchData=
[
  ['refresh_0',['refresh',['../class_keyboard_handler.html#a2003c680ac3bd532b8f798c86c502d9a',1,'KeyboardHandler::refresh()'],['../class_mouse_handler.html#a0a2ec80088166af48b1ad30a1d60c56a',1,'MouseHandler::refresh()']]],
  ['refreshbuffer_1',['refreshBuffer',['../class_object_manager.html#af1c59627b99e7a832cfbfa354e1f4418',1,'ObjectManager']]],
  ['removedirectdrawable_2',['removeDirectDrawable',['../class_object_manager.html#aaa6ce529c1fe119908cc31e768928dba',1,'ObjectManager']]],
  ['removeindiceddrawable_3',['removeIndicedDrawable',['../class_object_manager.html#ad2b5783b262a3b202c064fe100f69e03',1,'ObjectManager']]],
  ['removeindiceddrawabletextured_4',['removeIndicedDrawableTextured',['../class_object_manager.html#a89cb40f56a61ccb277c72175583d58d0',1,'ObjectManager']]],
  ['removepoint_5',['removePoint',['../class_poli_line.html#a16a1bda506ff58cc5fb5fef8c28bade8',1,'PoliLine::removePoint()'],['../class_triangle_fan.html#a2cf14ec6fcfd43196e725faf0f1223c7',1,'TriangleFan::removePoint()'],['../class_triangle_strip.html#ad57351e2bac47c5ece0ea985502bd98e',1,'TriangleStrip::removePoint()']]],
  ['render_6',['render',['../class_renderer.html#af7e5f8f68742f198e315fb4683a605a4',1,'Renderer']]],
  ['renderer_7',['Renderer',['../class_renderer.html#a6c733c0c6fe32ae8df3d194703043cf6',1,'Renderer']]],
  ['replacemanager_8',['replaceManager',['../class_renderer.html#a54391030d4726a294781dba082b5ec6e',1,'Renderer']]],
  ['rotate_9',['rotate',['../class_transformable_figure.html#ab8b04c2693506f8f1834331997d05e6a',1,'TransformableFigure']]]
];
