var class_bitmap_handler =
[
    [ "deleteBitmap", "class_bitmap_handler.html#a060b19d964745ddfca02aa50338b92bb", null ],
    [ "loadBitmap", "class_bitmap_handler.html#a9d84bc92f2a20eab2e49753df59c1a0f", null ]
];