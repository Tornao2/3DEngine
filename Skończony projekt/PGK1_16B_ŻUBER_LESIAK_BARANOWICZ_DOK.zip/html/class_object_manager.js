var class_object_manager =
[
    [ "ObjectManager", "class_object_manager.html#a6fa9372c7c3a8da88412f4158ca3dfd9", null ],
    [ "addDirectDrawable", "class_object_manager.html#a61cad0272210754b7b4ccd9ef7338421", null ],
    [ "addIndicedDrawable", "class_object_manager.html#a13e6eecfc4c75a2c61465de6eaf5f159", null ],
    [ "addIndicedDrawableTextured", "class_object_manager.html#a13b26e6ad2695ebf1d824ec625db6286", null ],
    [ "clearDirectList", "class_object_manager.html#a1b55550ff2b1f9ccb656497da4ca4f8b", null ],
    [ "clearIndicedList", "class_object_manager.html#a275e00c76e1b956803d36d6645e80a1c", null ],
    [ "clearIndicedTexturedList", "class_object_manager.html#a11d0f5e96a8c70e1db3a2f45c827d495", null ],
    [ "drawAll", "class_object_manager.html#a6f446751a6891b796cb10c8ef91c02f1", null ],
    [ "getCamera", "class_object_manager.html#abc9bf9c994bce86e26dff210013fd740", null ],
    [ "getDirectDrawable", "class_object_manager.html#a762ea7cd8388a3ffc689ebee8182bc5f", null ],
    [ "getIndicedDrawable", "class_object_manager.html#a60c377ce531ac92c30d6c004f27f900d", null ],
    [ "getIndicedDrawableTextured", "class_object_manager.html#acd6ab027e29d506a318b60fd95caea5b", null ],
    [ "refreshBuffer", "class_object_manager.html#af1c59627b99e7a832cfbfa354e1f4418", null ],
    [ "removeDirectDrawable", "class_object_manager.html#aaa6ce529c1fe119908cc31e768928dba", null ],
    [ "removeIndicedDrawable", "class_object_manager.html#ad2b5783b262a3b202c064fe100f69e03", null ],
    [ "removeIndicedDrawableTextured", "class_object_manager.html#a89cb40f56a61ccb277c72175583d58d0", null ],
    [ "setCamera", "class_object_manager.html#aa5f52f8802a599d32e5d64edbaa0636c", null ],
    [ "setShader", "class_object_manager.html#a2d9c80fed254e7063f12365fdaeb9a1d", null ]
];