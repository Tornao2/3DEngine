var class_keyboard_handler =
[
    [ "KeyboardHandler", "class_keyboard_handler.html#a3231b1f3ad96f40b7dccf4d095b79da4", null ],
    [ "checkIfPressed", "class_keyboard_handler.html#aeee2d2563202c4d405dbc3052a0e7826", null ],
    [ "getIfShouldRefresh", "class_keyboard_handler.html#a6b0dfdeb29dea39603686de11813dcca", null ],
    [ "refresh", "class_keyboard_handler.html#a2003c680ac3bd532b8f798c86c502d9a", null ],
    [ "setIfShouldRefresh", "class_keyboard_handler.html#a822af4da0c70d0c502c125110554506f", null ]
];