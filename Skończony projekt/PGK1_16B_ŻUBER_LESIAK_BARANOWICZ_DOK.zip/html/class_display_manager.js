var class_display_manager =
[
    [ "DisplayManager", "class_display_manager.html#a60cabab53f8655255b9a2406b212c34e", null ],
    [ "GetWindowHeight", "class_display_manager.html#ac7444a5e30c579e76c675a1b51f89bc7", null ],
    [ "getWindowWidth", "class_display_manager.html#add1fe456eac7dfd23a9007e776866168", null ],
    [ "ifFullscreen", "class_display_manager.html#aece7ddf38c3180c77c69003e7bfbf8db", null ],
    [ "initializeWindow", "class_display_manager.html#a9e8faef58efc226ca622d08f3930c9a4", null ],
    [ "setFullscreen", "class_display_manager.html#a56bb149f3df65e79d38eb4760794ccf8", null ],
    [ "setWindowHeight", "class_display_manager.html#a435fa81fae0b47f16cfc46a8c156e3ab", null ],
    [ "setWindowWidth", "class_display_manager.html#a0ae697d6e40adb135310cf6616321b50", null ]
];