var class_indice_draw =
[
    [ "getIndices", "class_indice_draw.html#a724c1cbfdf58d1542f34e0d26c4578d4", null ],
    [ "setIndices", "class_indice_draw.html#a63259ccc5d04b8b226205ce19f3de880", null ],
    [ "indices", "class_indice_draw.html#a990941076d29a3eade1f2aba7fca0b47", null ]
];