var class_player =
[
    [ "Player", "class_player.html#ae235b54c70a615e27d556948a38d5c4d", null ],
    [ "getMsX", "class_player.html#a17c69fa737ec4f36a7c147ef20c21053", null ],
    [ "getMsY", "class_player.html#a5dfafa5c9bb873e63fd65b682b77ab9e", null ],
    [ "getMsZ", "class_player.html#a306f86ac0fb33c7c125fd995b0f077b9", null ],
    [ "setMsX", "class_player.html#acac17b28afb4a34be141c25b803aa21a", null ],
    [ "setMsY", "class_player.html#a419c686a073b4e94596a0357dee2ccc8", null ],
    [ "setMsZ", "class_player.html#a93cc38a13cb795512fb7a19500ee4f17", null ],
    [ "msX", "class_player.html#a5155bbadbd8366e563e076d7ecf79760", null ],
    [ "msY", "class_player.html#a7564030614ca6044ca6b89638a4ce2af", null ],
    [ "msZ", "class_player.html#aa618fbc861ac8c7a72eeb261c59e5f60", null ]
];