var class_cube_textured =
[
    [ "CubeTextured", "class_cube_textured.html#a9f5a49723b33d6adc654c29970fbb7e7", null ]
];