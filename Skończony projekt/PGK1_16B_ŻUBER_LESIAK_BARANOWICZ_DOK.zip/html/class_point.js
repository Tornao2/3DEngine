var class_point =
[
    [ "Point", "class_point.html#a13fb95f7ca32e471252914dc228a862c", null ],
    [ "drawDirect", "class_point.html#ac99ab878fbcba21c7286c68c9cfb069b", null ]
];