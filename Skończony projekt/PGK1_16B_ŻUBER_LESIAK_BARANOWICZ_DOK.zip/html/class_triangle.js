var class_triangle =
[
    [ "Triangle", "class_triangle.html#ae746d09e9029fe17c7d8aa68b20f5a6f", null ],
    [ "drawDirect", "class_triangle.html#a89160df6ab6193d34bb24479d783cc97", null ]
];