var class_resizable =
[
    [ "getSize", "class_resizable.html#a41a44c6884b10620eef80b8d7d640116", null ],
    [ "setSize", "class_resizable.html#adbdc3bb7c4af93eeaf8c87b87425d053", null ],
    [ "size", "class_resizable.html#ad6552a8e871edc7b14c7d82214dbf81e", null ]
];