var class_figures =
[
    [ "changePoint", "class_figures.html#a3ac30b84b22cecf8492781bfd6e555e7", null ],
    [ "getData", "class_figures.html#ad69d6163b2a0d400c6b3a1ff6b226960", null ],
    [ "getDataCount", "class_figures.html#a497b48f5c4952b63e00918052a475f24", null ],
    [ "getPoint", "class_figures.html#aba1c02d2ba0e71c8251c0bbf6c29859c", null ],
    [ "getTextured", "class_figures.html#a8a7613b905bb9a7afb4d264852d187fe", null ],
    [ "setData", "class_figures.html#aa4007cad24ebe86401bfdb65438b1cff", null ],
    [ "setTextured", "class_figures.html#a9f54920921f3f2796c5bd1f0f5daf584", null ],
    [ "updateIndex", "class_figures.html#a015e3ec22f9dc2d69cfebf39d5b1961a", null ],
    [ "data", "class_figures.html#ab377ebe70185be8f7df3e2197508272d", null ],
    [ "isTextured", "class_figures.html#a136194427a698f8ae10a80becfdab035", null ]
];