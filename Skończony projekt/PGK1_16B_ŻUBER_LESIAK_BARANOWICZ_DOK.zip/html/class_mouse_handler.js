var class_mouse_handler =
[
    [ "MouseHandler", "class_mouse_handler.html#aeafc3781635558115e8188bbb7d976b5", null ],
    [ "checkIfPressed", "class_mouse_handler.html#a124cf210862f6f73623d0c3ee3232dbf", null ],
    [ "getCamera", "class_mouse_handler.html#a1b695ba629dc03451124716ac016a732", null ],
    [ "getIfShouldRefresh", "class_mouse_handler.html#a67c7635a2d529a68f9a67e7dcb37de37", null ],
    [ "refresh", "class_mouse_handler.html#a0a2ec80088166af48b1ad30a1d60c56a", null ],
    [ "setCamera", "class_mouse_handler.html#a8bcfcebea16d43c0b5f202ebed2041f4", null ],
    [ "setIfShouldRefresh", "class_mouse_handler.html#a00272c3927585f666d3123101b594e83", null ]
];