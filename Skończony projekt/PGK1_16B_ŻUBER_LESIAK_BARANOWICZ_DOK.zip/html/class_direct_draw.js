var class_direct_draw =
[
    [ "drawDirect", "class_direct_draw.html#a4e88e6b5973cd0f908f302decf02bb16", null ]
];