var class_engine =
[
    [ "Engine", "class_engine.html#aace4bafdd94c719c1c45ce6e74e9c4e9", null ],
    [ "getFpsCap", "class_engine.html#ad660a3d94402c8ce1553d3505a6328e4", null ],
    [ "setFpsCap", "class_engine.html#a2d6ab89de87c025f050d0629657c37c8", null ],
    [ "toggleKeyboard", "class_engine.html#af6ccc3718b3eeb799fc16819a2a07624", null ],
    [ "toggleMouse", "class_engine.html#a7d63082acd3eb2e8447d5d6f0f23d488", null ]
];