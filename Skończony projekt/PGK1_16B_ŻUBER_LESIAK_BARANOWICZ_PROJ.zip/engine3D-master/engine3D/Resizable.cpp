#include "Resizable.h"

float Resizable::getSize() {
	return size;
}

void Resizable::setSize(float readSize) {
	size = readSize;
}