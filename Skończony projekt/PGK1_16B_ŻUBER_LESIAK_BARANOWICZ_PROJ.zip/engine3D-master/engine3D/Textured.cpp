#include "Textured.h"

void Textured::setTextureId(int readTextureId) {
	textureId = readTextureId;
}

int Textured::getTextureId() {
	return textureId;
}